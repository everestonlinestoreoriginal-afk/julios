import SwiftUI

struct HomeView: View {
    
    let products = [
        Product(name: "Chaqueta Oversize", price: "$120"),
        Product(name: "Zapatillas Urban", price: "$95"),
        Product(name: "Polera Básica", price: "$40")
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(products) { product in
                        NavigationLink(destination: ProductDetailView(product: product)) {
                            ProductCard(product: product)
                        }
                    }
                    NavigationLink(destination: ProductosAPIView()) {
                                       Text("Productos API")
                                           .frame(maxWidth: .infinity)
                                           .padding()
                                           .background(Color.black)
                                           .foregroundColor(.white)
                                           .cornerRadius(12)
                                   }
                    NavigationLink(destination: ClientesView()) {
                        Text("Clientes")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .foregroundColor(.white)
                            .cornerRadius(14)
                    }
                }
                .padding()
            }
            .background(AppColors.background)
            .navigationTitle("New Collection")
            .navigationBarItems(trailing:
                                    NavigationLink(destination: ProfileView()) {
                                        Image(systemName: "person.circle")
                                            .font(.title2)
                                    }
                                )

        }
    }
}
