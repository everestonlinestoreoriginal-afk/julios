import SwiftUI

struct HomeView: View {
    
    @AppStorage("logueado") var logueado = false
    @AppStorage("nombreUsuario") var nombreUsuario = ""
    @AppStorage("rolUsuario") var rolUsuario = ""
    
    let products = [
        Product(name: "Chaqueta Oversize", price: "$120"),
        Product(name: "Zapatillas Urban", price: "$95"),
        Product(name: "Polera Básica", price: "$40")
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    
                    // ✅ Bienvenida
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Bienvenido, \(nombreUsuario)")
                            .font(.title2.bold())
                        
                        Text("Rol: \(rolUsuario)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    Divider()
                    
                    // ✅ Productos locales (colección)
                    Text("Nueva Colección")
                        .font(.headline)
                    
                    ForEach(products) { product in
                        NavigationLink(destination: ProductDetailView(product: product)) {
                            ProductCard(product: product)
                        }
                    }
                    
                    Divider()
                    
                    // ✅ Sección navegación principal
                    Text("Explorar")
                        .font(.headline)
                    
                    NavigationLink("Categorías") {
                        CategoriasView()
                    }
                    .botonEstilo()
                    
                    NavigationLink("Clientes") {
                        ClientesView()
                    }
                    .botonEstilo()
                    
                    NavigationLink("Productos API") {
                        ProductosAPIView()
                    }
                    .botonEstilo()
                }
                .padding()
            }
            .background(AppColors.background)
            .navigationTitle("Fashion Store")
            .toolbar {
                
                // ✅ Perfil
                ToolbarItem(placement: .navigationBarLeading) {
                    NavigationLink(destination: ProfileView()) {
                        Image(systemName: "person.circle")
                            .font(.title2)
                    }
                }
                
                // ✅ Logout
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Salir") {
                        logueado = false
                        nombreUsuario = ""
                        rolUsuario = ""
                    }
                }
            }
        }
    }
}

extension View {
    func botonEstilo() -> some View {
        self
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(14)
    }
}
