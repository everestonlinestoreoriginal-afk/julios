import SwiftUI

struct ProductCard: View {
    
    let product: Product
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            
            // Imagen simulada (diseño sin Assets)
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(AppColors.card)
                    .frame(height: 180)
                
                Image(systemName: "tshirt.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80)
                    .foregroundColor(.black)
            }
            
            Text(product.name)
                .font(.headline)
            
            Text(product.price)
                .font(.subheadline)
                .foregroundColor(AppColors.secondary)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
    }
}
