
import SwiftUI

@main
struct TiendaAppApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}
