import SwiftUI

@main
struct TiendaAppApp: App {
    
    @AppStorage("logueado") var logueado = false
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                if logueado {
                    HomeView()
                } else {
                    LoginView()
                }
            }
        }
    }
}
