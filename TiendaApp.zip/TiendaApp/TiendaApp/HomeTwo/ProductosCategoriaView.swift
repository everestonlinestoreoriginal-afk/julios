import SwiftUI
struct ProductoCategoria: Identifiable, Decodable {
    let idproducto: String
    let nombre: String
    let precio: String
    let stock: String
    
    var id: String { idproducto }
}

struct ProductosCategoriaView: View {
    
    let idCategoria: String
    @State private var productos: [ProductoCategoria] = []
    
    var body: some View {
        List(productos) { producto in
            VStack(alignment: .leading) {
                Text(producto.nombre)
                    .font(.headline)
                Text("Precio: \(producto.precio)")
                Text("Stock: \(producto.stock)")
                    .foregroundColor(.gray)
            }
        }
        .navigationTitle("Productos")
        .onAppear {
            cargarProductos()
        }
    }
    
    func cargarProductos() {
        let url = URL(string:
            "https://isilpa.alwaysdata.net/productos_categoria.php?idcategoria=\(idCategoria)"
        )!
        
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data {
                let resultado = try? JSONDecoder().decode([ProductoCategoria].self, from: data)
                DispatchQueue.main.async {
                    productos = resultado ?? []
                }
            }
        }.resume()
    }
}
