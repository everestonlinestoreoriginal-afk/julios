import SwiftUI

struct CategoriasView: View {
    
    @State private var categorias: [Categoria] = []
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                ForEach(categorias) { categoria in
                    NavigationLink {
                        ProductosCategoriaView(idCategoria: categoria.idcategoria)
                    } label: {
                        HStack(spacing: 15) {
                            
                            // ✅ Icono decorativo
                            ZStack {
                                Circle()
                                    .fill(Color.black.opacity(0.1))
                                    .frame(width: 50, height: 50)
                                
                                Image(systemName: "bag.fill")
                                    .foregroundColor(.black)
                            }
                            
                            // ✅ Texto
                            VStack(alignment: .leading, spacing: 6) {
                                Text(categoria.nombre)
                                    .font(.headline)
                                    .foregroundColor(.black)
                                
                                Text(categoria.descripcion)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                    .lineLimit(2)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
                    }
                }
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Categorías")
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            cargarCategorias()
        }
    }


    
    func cargarCategorias() {
        let url = URL(string: "https://isilpa.alwaysdata.net/categorias.php")!
        
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data {
                let resultado = try? JSONDecoder().decode([Categoria].self, from: data)
                DispatchQueue.main.async {
                    categorias = resultado ?? []
                }
            }
        }.resume()
    }
}
