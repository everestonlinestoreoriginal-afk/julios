import SwiftUI

struct LoginResponse: Decodable {
    let success: Bool
    let nombre: String?
    let rol: String?
}

struct LoginView: View {
    
    @State private var usuario = ""
    @State private var password = ""
    @State private var mostrarAlerta = false
    @State private var mensaje = ""
    @State private var cargando = false
    
    @AppStorage("logueado") var logueado = false
    @AppStorage("nombreUsuario") var nombreUsuario = ""
    @AppStorage("rolUsuario") var rolUsuario = ""
    
    var body: some View {
        VStack(spacing: 25) {
            
            Spacer()
            
            Text("Fashion Store")
                .font(.largeTitle.bold())
            
            TextField("Usuario", text: $usuario)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .autocapitalization(.none)
            
            SecureField("Contraseña", text: $password)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
            
            Button {
                login()
            } label: {
                if cargando {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding()
                } else {
                    Text("Iniciar Sesión")
                        .frame(maxWidth: .infinity)
                        .padding()
                }
            }
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(12)
            
            Spacer()
        }
        .padding()
        .alert(mensaje, isPresented: $mostrarAlerta) {
            Button("OK", role: .cancel) { }
        }
    }
    
    func login() {
        
        // ✅ Validación básica
        if usuario.isEmpty || password.isEmpty {
            mensaje = "Complete todos los campos"
            mostrarAlerta = true
            return
        }
        
        cargando = true
        
        guard let url = URL(string: "https://isilpa.alwaysdata.net/login.php") else {
            mensaje = "URL inválida"
            mostrarAlerta = true
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        let body = "usuario=\(usuario)&password=\(password)"
        request.httpBody = body.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                cargando = false
            }
            
            if let error = error {
                DispatchQueue.main.async {
                    mensaje = "Error de conexión: \(error.localizedDescription)"
                    mostrarAlerta = true
                }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    mensaje = "No se recibió respuesta del servidor"
                    mostrarAlerta = true
                }
                return
            }
            
            do {
                let respuesta = try JSONDecoder().decode(LoginResponse.self, from: data)
                
                DispatchQueue.main.async {
                    if respuesta.success {
                        nombreUsuario = respuesta.nombre ?? ""
                        rolUsuario = respuesta.rol ?? ""
                        logueado = true
                    } else {
                        mensaje = "Usuario o contraseña incorrectos"
                        mostrarAlerta = true
                    }
                }
                
            } catch {
                DispatchQueue.main.async {
                    mensaje = "Error al procesar respuesta del servidor"
                    mostrarAlerta = true
                }
            }
            
        }.resume()
    }
}

