struct Categoria: Identifiable, Decodable {
    let idcategoria: String
    let nombre: String
    let descripcion: String
    
    var id: String { idcategoria }
}
