import SwiftUI

struct ProfileView: View {
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                
                Image(systemName: "storefront.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80)
                    .foregroundColor(.black)
                
                Text("Fashion Store")
                    .font(.system(size: 26, weight: .bold))
                
                Text("Tienda especializada en moda urbana y minimalista.")
                    .font(.body)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                
                VStack(alignment: .leading, spacing: 12) {
                    Label("Av. Principal 123", systemImage: "location.fill")
                    Label("+56 9 1234 5678", systemImage: "phone.fill")
                    Label("contacto@fashionstore.com", systemImage: "envelope.fill")
                }
                .foregroundColor(.black)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.systemGray6))
                .cornerRadius(16)
            }
            .padding()
        }
        .navigationTitle("Perfil")
    }
}
