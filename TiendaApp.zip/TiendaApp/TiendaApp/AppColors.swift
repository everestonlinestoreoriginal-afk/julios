import SwiftUI

struct AppColors {
    static let background = Color.white
    static let primary = Color.black
    static let secondary = Color.gray.opacity(0.6)
    static let card = Color(.systemGray6)
}
