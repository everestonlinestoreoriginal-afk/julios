import SwiftUI

struct ProductDetailView: View {
    
    let product: Product
    
    @State private var animateImage = false
    @State private var showContent = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                
                // Animación 1: Imagen
                ZStack {
                    RoundedRectangle(cornerRadius: 0)
                        .fill(AppColors.card)
                        .frame(height: 320)
                    
                    Image(systemName: "tshirt.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120)
                        .scaleEffect(animateImage ? 1 : 0.8)
                        .animation(.easeOut(duration: 1), value: animateImage)
                }
                
                VStack(alignment: .leading, spacing: 12) {
                    Text(product.name)
                        .font(.system(size: 26, weight: .bold))
                    
                    Text(product.price)
                        .font(.title2)
                        .foregroundColor(AppColors.secondary)
                    
                    Text("Producto de alta calidad diseñado para uso diario, alineado con las últimas tendencias de moda.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .padding(.top, 8)
                }
                .opacity(showContent ? 1 : 0)
                .animation(.easeIn(duration: 1), value: showContent)
                
                // Animación 2: Botón
                Button(action: {}) {
                    Text("Agregar al carrito")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(14)
                }
                .opacity(showContent ? 1 : 0)
                
                Spacer()
            }
        }
        .onAppear {
            animateImage = true
            showContent = true
        }
    }
}
