import SwiftUI

struct SplashView: View {
    
    @State private var isActive = false
    
    var body: some View {
        ZStack {
            AppColors.background
            
            VStack(spacing: 12) {
                Image(systemName: "bag.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .foregroundColor(.black)
                
                Text("FASHION")
                    .font(.system(size: 28, weight: .bold))
                
                Text("Store App")
                    .font(.system(size: 14))
                    .foregroundColor(AppColors.secondary)
            }
        }
        .ignoresSafeArea()
        .onAppear {
            // Temporizador no visto en clase
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                isActive = true
            }
        }
    }
}
