import SwiftUI

struct ProductosAPIView: View {

    @State private var productos: [ProductoRopa] = []

    var body: some View {
        List(productos) { producto in
            VStack(alignment: .leading, spacing: 6) {
                Text(producto.nombre)
                    .font(.headline)

                Text("Categoría: \(producto.categoria)")
                Text("Precio: S/ \(producto.precio)")
                Text("Talla: \(producto.talla)")
            }
        }
        .navigationTitle("Productos")
        .onAppear {
            cargarProductos()
        }
    }
    func cargarProductos() {
        let urlString = "https://isilpa.alwaysdata.net/productos.php"
        guard let url = URL(string: urlString) else { return }

        URLSession.shared.dataTask(with: url) { data, _, error in
            
            if let error = error {
                print("Error:", error)
                return
            }

            guard let data = data else { return }

            do {
                let productos = try JSONDecoder().decode([ProductoRopa].self, from: data)
                DispatchQueue.main.async {
                    self.productos = productos
                }
            } catch {
                print("Error al decodificar:", error)
            }

        }.resume()
    }

}
