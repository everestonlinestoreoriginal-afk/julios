struct Cliente: Identifiable, Decodable {
    let idcliente: Int
    let empresa: String?
    let nombres: String?
    let correo: String?
    let ciudad: String?

    var id: Int { idcliente }
}
