struct Cliente: Identifiable, Decodable {
    let idcliente: String
    let empresa: String
    let nombres: String
    let correo: String
    let ciudad: String

    var id: String { idcliente }
}
