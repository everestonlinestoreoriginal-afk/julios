struct ProductoRopa: Identifiable, Decodable {

    let idproducto: String
    let nombre: String
    let categoria: String
    let precio: String
    let talla: String
    let imagen: String

    var id: String { idproducto }
}
