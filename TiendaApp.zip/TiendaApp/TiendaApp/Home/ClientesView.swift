import SwiftUI

struct ClientesView: View {

    @State private var clientes: [Cliente] = []

    var body: some View {
        List(clientes) { cliente in
            NavigationLink(
                destination: PedidosView(idCliente: cliente.idcliente)
            ) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(cliente.empresa ?? "Sin empresa")
                        .font(.headline)
                    
                    Text(cliente.nombres ?? "")
                    
                    Text(cliente.correo ?? "")
                        .font(.caption)
                        .foregroundColor(.gray)
                    
                    Text(cliente.ciudad ?? "")
                        .font(.caption)
                }

            }
        }
        .navigationTitle("Clientes")
        .onAppear {
            cargarClientes()
        }
    }

    func cargarClientes() {
        let url = URL(string: "https://servicios.campus.pe/clientes.php")!

        URLSession.shared.dataTask(with: url) { data, response, error in
            
            if let error = error {
                print("Error:", error.localizedDescription)
                return
            }

            guard let data = data else {
                print("No hay datos")
                return
            }

            print("Respuesta:", String(data: data, encoding: .utf8) ?? "")

            do {
                let resultado = try JSONDecoder().decode([Cliente].self, from: data)
                DispatchQueue.main.async {
                    clientes = resultado
                }
            } catch {
                print("Error decode:", error)
            }

        }.resume()
    }

}
