import SwiftUI

struct ClientesView: View {

    @State private var clientes: [Cliente] = []

    var body: some View {
        List(clientes) { cliente in
            NavigationLink(
                destination: PedidosView(idCliente: cliente.idcliente)
            ) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(cliente.empresa)
                        .font(.headline)
                    Text(cliente.nombres)
                    Text(cliente.correo)
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text(cliente.ciudad)
                        .font(.caption)
                }
            }
        }
        .navigationTitle("Clientes")
        .onAppear {
            cargarClientes()
        }
    }

    func cargarClientes() {
        let url = URL(string: "https://servicios.campus.pe/clientes.php")!

        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data {
                let decoder = JSONDecoder()
                if let resultado = try? decoder.decode([Cliente].self, from: data) {
                    DispatchQueue.main.async {
                        clientes = resultado
                    }
                }
            }
        }.resume()
    }
}
