import SwiftUI

struct PedidosView: View {

    let idCliente: String
    @State private var pedidos: [Pedido] = []

    var body: some View {
        List(pedidos) { pedido in
            VStack(alignment: .leading, spacing: 4) {
                Text("Pedido #\(pedido.idpedido)")
                    .font(.headline)

                Text("Fecha: \(pedido.fechapedido)")
                Text("Entrega: \(pedido.fechaentrega ?? "No definida")")
                Text("Cargo: $\(pedido.cargo)")
                Text("Empleado: \(pedido.empleado)")
                Text("País: \(pedido.paisdestinatario ?? "-")")
            }

        }
        .navigationTitle("Pedidos")
        .onAppear {
            cargarPedidos()
        }
    }

    func cargarPedidos() {
        let url = URL(string:
            "https://servicios.campus.pe/pedidoscliente.php?idcliente=\(idCliente)"
        )!

        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data {
                let decoder = JSONDecoder()
                if let resultado = try? decoder.decode([Pedido].self, from: data) {
                    DispatchQueue.main.async {
                        pedidos = resultado
                    }
                }
            }
        }.resume()
    }
}
