struct Pedido: Identifiable, Decodable {

    let idpedido: String
    let fechapedido: String
    let fechaentrega: String?
    let cargo: String
    let empleado: String
    let paisdestinatario: String?

    var id: String { idpedido }
}
