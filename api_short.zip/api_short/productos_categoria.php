<?php
header("Content-Type: application/json");
include("conexion.php");

$idcategoria = $_GET["idcategoria"];

$sql = "SELECT idproducto, nombre, precio, stock 
        FROM productos 
        WHERE idcategoria = $idcategoria";

$resultado = mysqli_query($conexion, $sql);

$datos = [];

while ($fila = mysqli_fetch_assoc($resultado)) {
    $datos[] = $fila;
}

echo json_encode($datos);
?>
