<?php
header("Content-Type: application/json");
include("conexion.php");

$usuario = $_POST["usuario"];
$password = $_POST["password"];

$sql = "SELECT * FROM usuarios 
        WHERE usuario='$usuario' AND password='$password'";

$resultado = mysqli_query($conexion, $sql);

if (mysqli_num_rows($resultado) > 0) {
    
    $fila = mysqli_fetch_assoc($resultado);
    
    echo json_encode([
        "success" => true,
        "nombre" => $fila["nombre"],
        "rol" => $fila["rol"]
    ]);
    
} else {
    
    echo json_encode(["success" => false]);
}
?>
